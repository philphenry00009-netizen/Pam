# PHIRMS – professional camera for Android (v0.4, Blackmagic-style interface)

Native Kotlin + Camera2. App ID `com.phrms.camera`, Android 10+ (API 29). Original code and branding; not affiliated with Blackmagic Design.
Build: push the zip to GitHub (see the workflow in `.github/workflows/build.yml`) and download the `PHIRMS-debug-apk` artifact.

## Interface
HUD row (tap a value for quick controls): LENS, FPS, SHUTTER, IRIS, TIMECODE, ISO, WB, TINT, FORMAT, STORAGE.
Right column (landscape) / bottom row (portrait): monitor tools, focus (AF/MF, peaking, rack focus), exposure (auto/manual, EV, AE lock, zebra, false colour, look), record, photo, digital slate.
Tabs: Camera, Media (in-app list of PHIRMS files), Settings.
Gestures: swipe up/down = hide/show HUD; swipe right while recording = dim screen (tap to restore); long-press = AF/AE lock; pinch = zoom; tap = focus.

## Implemented (all hardware-dependent; nothing has been run on a device by the author)
Shutter speed/angle + 50/60 Hz flicker-free steps; manual ISO; iris (only if the phone exposes several apertures);
white balance presets + approximate manual Kelvin/tint (calibrated against the phone's own presets; needs MANUAL_POST_PROCESSING);
manual focus slider 0.00-1.00 with 3 rack-focus marks and speed; AF lock; zebra 75-100 %; focus peaking (5 colours); false colour (approximate);
RGB histogram with clipping markers; audio meters (L/R); thirds, crosshair, centre dot, level; frame guides 1.85/2.35/2.39/2.40/4:3/9:16/4:5/1:1;
anamorphic de-squeeze preview 1.33/1.55/2.0 and mirror (preview only); H.264/H.265, 720p-4K, 24-60 fps, bitrate 10-120 Mbps;
time-lapse (off-speed, no audio); lens buttons for the lenses the phone exposes; front/rear; microphone selection, direction, mono/stereo, AAC;
digital slate (project/reel/scene/take/good take/INT-EXT/DAY-NIGHT) used in the file name and description; external folder recording (USB/SD via folder picker);
volume keys start/stop; photo (JPEG) with optional portrait blur; looks (tone curves / camera effects when supported).

## Not possible or not implemented
ProRes, Apple Watch, Camera Control button, Blackmagic Cloud / DaVinci Resolve sync / chat (Apple/Blackmagic services);
3D LUT preview/bake (needs a GL pipeline); 10-bit and log; lens distortion correction; 120 fps high-speed slow motion; PCM/multi-channel audio and input gain
(MediaRecorder cannot do these); headphone monitoring; metadata embedded inside the MP4 (slate goes in file name and MediaStore description).

## v0.5 – right-hand vertical ruler menus
Tap LENS / FPS / SHUTTER / IRIS / ISO / WB / TINT (HUD) or the focus / exposure / zoom icons: an option column plus a vertical ruler dial opens on the right edge next to the action buttons, in portrait and landscape.
Drag or fling the ruler; it snaps to valid steps. Tap the same icon again to close.
Focus and exposure icons show "A" in auto and a padlock when manual or locked. Default frame rate is 25 fps; 120 fps appears when the phone reports a 120 fps high-speed mode (recorded without sound, fixed exposure).
Not available: live background blur in video (blur depth applies to PORTRAIT photos only).

## v0.6 – cleaner Blackmagic-style layout
Landscape: HUD across the top (labels over values, "A" badges, big timecode, 4K pill, AUTO button), action column on the right, then the tab column.
Portrait: HUD on top, action row and tabs along the bottom. The ruler menu is on the right edge in both.
Bottom of the picture: RGB histogram (left), storage time / % / GB (centre), L/R audio meters with dB scale (right).
Sizes scale with the screen's short side and respect camera cut-outs. The orientation locks while recording so the layout and file orientation stay fixed.
