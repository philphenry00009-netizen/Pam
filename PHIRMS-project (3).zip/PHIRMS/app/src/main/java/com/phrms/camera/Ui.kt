package com.phrms.camera

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Record button: ring + disc. Red ring (Blackmagic style); recording = rounded square. */
class ShutterView(c: Context) : View(c) {
    var rec = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 3 * d
        p.style = Paint.Style.STROKE; p.strokeWidth = 4 * d; p.color = 0xFFE5392F.toInt()
        cv.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL; p.color = 0xFFFF3B30.toInt()
        if (rec) { val s = r * 0.42f; cv.drawRoundRect(cx - s, cy - s, cx + s, cy + s, 6 * d, 6 * d, p) }
        else cv.drawCircle(cx, cy, r - 8 * d, p)
    }
}

/** Drawn icons (no image assets). 0 gear, 3 camera, 4 media/film, 5 monitor/frame, 6 focus A, 7 exposure A, 8 slate. */
class IconView(c: Context, private val kind: Int) : View(c) {
    var tint = Color.WHITE
        set(v) { if (field != v) { field = v; invalidate() } }
    var badge = 0   // 0 none, 1 "A" (auto), 2 padlock (manual / locked)
        set(v) { if (field != v) { field = v; invalidate() } }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density
    private fun brackets(cv: Canvas, l: Float, t: Float, r: Float, b: Float, k: Float) {
        cv.drawLine(l, t, l + k, t, p); cv.drawLine(l, t, l, t + k, p)
        cv.drawLine(r, t, r - k, t, p); cv.drawLine(r, t, r, t + k, p)
        cv.drawLine(l, b, l + k, b, p); cv.drawLine(l, b, l, b - k, p)
        cv.drawLine(r, b, r - k, b, p); cv.drawLine(r, b, r, b - k, p)
    }
    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        p.color = tint; p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d
        when (kind) {
            0 -> {
                cv.drawCircle(cx, cy, s * 0.24f, p); cv.drawCircle(cx, cy, s * 0.09f, p)
                p.strokeWidth = 3f * d
                for (i in 0 until 8) { val a = Math.toRadians(i * 45.0)
                    cv.drawLine(cx + (s * 0.24f * cos(a)).toFloat(), cy + (s * 0.24f * sin(a)).toFloat(), cx + (s * 0.36f * cos(a)).toFloat(), cy + (s * 0.36f * sin(a)).toFloat(), p) }
            }
            3 -> {
                cv.drawRoundRect(cx - s * 0.38f, cy - s * 0.22f, cx + s * 0.38f, cy + s * 0.3f, 4 * d, 4 * d, p)
                cv.drawCircle(cx, cy + s * 0.04f, s * 0.14f, p)
                cv.drawLine(cx - s * 0.12f, cy - s * 0.22f, cx - s * 0.06f, cy - s * 0.32f, p); cv.drawLine(cx - s * 0.06f, cy - s * 0.32f, cx + s * 0.1f, cy - s * 0.32f, p)
            }
            4 -> {
                cv.drawRoundRect(cx - s * 0.36f, cy - s * 0.28f, cx + s * 0.36f, cy + s * 0.28f, 3 * d, 3 * d, p)
                for (i in -1..1) { cv.drawLine(cx - s * 0.36f, cy + i * s * 0.18f, cx - s * 0.26f, cy + i * s * 0.18f, p); cv.drawLine(cx + s * 0.26f, cy + i * s * 0.18f, cx + s * 0.36f, cy + i * s * 0.18f, p) }
                val tri = Path(); tri.moveTo(cx - s * 0.07f, cy - s * 0.1f); tri.lineTo(cx + s * 0.1f, cy); tri.lineTo(cx - s * 0.07f, cy + s * 0.1f); tri.close()
                p.style = Paint.Style.FILL; cv.drawPath(tri, p)
            }
            5 -> brackets(cv, cx - s * 0.32f, cy - s * 0.24f, cx + s * 0.32f, cy + s * 0.24f, s * 0.14f)
            6 -> {
                brackets(cv, cx - s * 0.34f, cy - s * 0.3f, cx + s * 0.34f, cy + s * 0.3f, s * 0.12f)
                cv.drawCircle(cx - s * 0.06f, cy, s * 0.1f, p)
            }
            7 -> {
                cv.drawCircle(cx - s * 0.06f, cy, s * 0.22f, p)
                cv.drawLine(cx - s * 0.16f, cy - s * 0.06f, cx + s * 0.04f, cy - s * 0.06f, p); cv.drawLine(cx - s * 0.06f, cy - s * 0.16f, cx - s * 0.06f, cy + s * 0.04f, p)
                cv.drawLine(cx - s * 0.14f, cy + s * 0.12f, cx + s * 0.02f, cy + s * 0.12f, p)
            }
            9 -> {
                cv.drawCircle(cx - s * 0.06f, cy - s * 0.06f, s * 0.2f, p)
                cv.drawLine(cx + s * 0.09f, cy + s * 0.09f, cx + s * 0.3f, cy + s * 0.3f, p)
                cv.drawLine(cx - s * 0.15f, cy - s * 0.06f, cx + s * 0.03f, cy - s * 0.06f, p)
                cv.drawLine(cx - s * 0.06f, cy - s * 0.15f, cx - s * 0.06f, cy + s * 0.03f, p)
            }
            else -> {
                cv.drawRoundRect(cx - s * 0.34f, cy - s * 0.08f, cx + s * 0.34f, cy + s * 0.3f, 3 * d, 3 * d, p)
                cv.drawRoundRect(cx - s * 0.34f, cy - s * 0.3f, cx + s * 0.34f, cy - s * 0.1f, 3 * d, 3 * d, p)
                for (i in 0 until 4) cv.drawLine(cx - s * 0.3f + i * s * 0.17f, cy - s * 0.1f, cx - s * 0.2f + i * s * 0.17f, cy - s * 0.3f, p)
            }
        }
        if (badge == 1) {
            p.style = Paint.Style.FILL; p.color = 0xFF3CC8E8.toInt(); p.textSize = s * 0.3f; p.typeface = Typeface.DEFAULT_BOLD
            cv.drawText("A", cx + s * 0.22f, cy + s * 0.42f, p)
        } else if (badge == 2) {
            p.style = Paint.Style.FILL; p.color = 0xFFFFC107.toInt()
            cv.drawRoundRect(cx + s * 0.16f, cy + s * 0.2f, cx + s * 0.4f, cy + s * 0.42f, 2 * d, 2 * d, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f * d
            cv.drawArc(RectF(cx + s * 0.2f, cy + s * 0.07f, cx + s * 0.36f, cy + s * 0.31f), 180f, 180f, false, p)
        }
    }
}